# COVENANT — Build Agent Prompt
## ZK-Verifiable Compliance Credentials for Cross-Border Private Settlement on Stellar

---

## 🎯 MISSION

Build a complete, production-ready ZK system that enables **private cross-border stablecoin settlement with embedded compliance verification** on Stellar. Every transaction requires a ZK proof; without it, the contract rejects. This is not a privacy pool. This is not a mixer. This is **configurable privacy with provable compliance** — where privacy and compliance are not trade-offs but mutually reinforcing properties.

**Deadline**: June 29, 2026, 12:00PM PST (5 days remaining)
**Prize Pool**: $10,000 USD (1st: $5,000)
**Hackathon**: Stellar Hacks: Real-World ZK

---

## 📁 PROJECT STRUCTURE

```
covenant/
├── README.md                          # Project overview
├── Cargo.toml                         # Workspace configuration  
├── package.json                       # Frontend dependencies
├── justfile                           # Task runner (all commands)
├── .gitignore                         # Git ignore rules
│
├── circuits/
│   ├── compliance_credential/         # Noir circuit
│   │   ├── Nargo.toml
│   │   └── src/main.nr
│   └── private_settlement/            # Noir circuit
│       ├── Nargo.toml
│       └── src/main.nr
│
├── contracts/
│   ├── covenant_registry/             # Credential registry
│   │   ├── Cargo.toml
│   │   └── src/lib.rs
│   ├── covenant_settlement/           # Settlement execution
│   │   ├── Cargo.toml
│   │   └── src/lib.rs
│   ├── covenant_compliance_bridge/    # Cross-currency bridge
│   │   ├── Cargo.toml
│   │   └── src/lib.rs
│   └── ultrahonk_verifier/            # Proof verifier wrapper
│       ├── Cargo.toml
│       └── src/lib.rs
│
├── frontend/                          # React + TypeScript
│   ├── index.html
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tsconfig.node.json
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── index.css
│       └── components/
│           ├── Dashboard.tsx
│           ├── CredentialPanel.tsx
│           ├── SettlementPanel.tsx
│           └── RegulatorPanel.tsx
│
├── scripts/
│   ├── deploy.sh                      # Deployment script
│   └── generate_proof.sh              # Proof generation
│
└── docs/
    ├── ARCHITECTURE.md
    ├── CIRCUITS.md
    └── HACKATHON_SUBMISSION.md
```

---

## 🔧 PREREQUISITES

Install these BEFORE starting:

```bash
# Rust + wasm32 target
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
rustup target add wasm32v1-none

# Stellar CLI (v3.2.0+)
cargo install stellar-cli --locked

# Noir + Barretenberg
bash <(curl -fsSL https://noir-lang.org/install)
nargo --version  # Should show 1.0.0-beta.9
bb --version     # Should show 0.87.0

# Node.js 18+
npm install -g n
n 18

# just task runner
cargo install just
```

---

## 🚀 BUILD COMMANDS

### Phase 1: Environment Setup
```bash
just setup          # Verify all dependencies installed
just start          # Start local Stellar network in Docker
```

### Phase 2: Circuit Building
```bash
just build-circuits
```
This runs:
```bash
# For each circuit:
cd circuits/compliance_credential && nargo compile && nargo execute
bb write_vk -b ./target/compliance_credential.json -o ./target
bb prove -b ./target/compliance_credential.json -w ./target/compliance_credential.gz -o ./target

cd circuits/private_settlement && nargo compile && nargo execute
bb write_vk -b ./target/private_settlement.json -o ./target
bb prove -b ./target/private_settlement.json -w ./target/private_settlement.gz -o ./target
```

### Phase 3: Contract Building
```bash
just build-contracts
```
This runs:
```bash
cargo build --workspace --release --target wasm32v1-none
```

### Phase 4: Deployment
```bash
just deploy
```
This runs:
```bash
# Fund admin
stellar keys generate alice --network local --fund

# Deploy CovenantRegistry
stellar contract deploy --wasm target/wasm32v1-none/release/covenant_registry.wasm \
    --source-account alice --network local --alias covenant_registry

# Initialize Registry
stellar contract invoke --id covenant_registry --source-account alice --network local \
    -- initialize --admin <ADDRESS> --issuer_root <ROOT> --verification_key <VK>

# Deploy CovenantSettlement
stellar contract deploy --wasm target/wasm32v1-none/release/covenant_settlement.wasm \
    --source-account alice --network local --alias covenant_settlement

# Initialize Settlement
stellar contract invoke --id covenant_settlement --source-account alice --network local \
    -- initialize --admin <ADDRESS> --registry_address <REGISTRY_ID>

# Deploy CovenantComplianceBridge
stellar contract deploy --wasm target/wasm32v1-none/release/covenant_compliance_bridge.wasm \
    --source-account alice --network local --alias covenant_compliance_bridge

# Initialize Bridge
stellar contract invoke --id covenant_compliance_bridge --source-account alice --network local \
    -- initialize --admin <ADDRESS> --settlement_address <SETTLEMENT_ID>
```

### Phase 5: Testing
```bash
just verify         # Run all tests
cargo test --workspace --all-features --release
```

### Phase 6: End-to-End
```bash
just e2e            # Full pipeline: start → build → deploy → verify
```

### Phase 7: Frontend
```bash
cd frontend
npm install
npm run dev         # Starts on http://localhost:3000
```

### Phase 8: Testnet Deployment
```bash
just testnet        # Deploy to Stellar testnet
```

---

## 📝 KEY IMPLEMENTATION NOTES

### Noir Circuits
- Use Poseidon2 for hashing (native Stellar host function)
- Merkle membership proofs for KYC/sanctions verification
- Range proofs for balance and risk score validation
- Nullifiers prevent credential replay

### Soroban Contracts
- Use `soroban-sdk` v22.0.7
- Use `soroban-token-sdk` for Stellar Asset Contract integration
- Persistent storage for credentials and nullifiers
- Events for all state changes
- Auth required for sensitive operations

### Frontend
- React 18 + TypeScript + Tailwind CSS
- Lucide icons
- Zustand for state management
- Connect to Freighter wallet
- Call Soroban contracts via Stellar SDK

### ZK Proof Verification
- Use Stellar Protocol 26 BN254 host functions
- Reference: github.com/yugocabrio/rs-soroban-ultrahonk
- UltraHonk proofs verified natively on-chain

---

## 🎥 DEMO VIDEO REQUIREMENTS

Record a 2-3 minute walkthrough showing:

1. **Problem** (30s): Show public Stellar transaction, explain privacy/compliance paradox
2. **Credential Generation** (60s): Generate compliance credential with Noir proof
3. **Private Settlement** (45s): Execute private settlement with ZK verification
4. **Regulator Audit** (45s): Show selective disclosure with view key
5. **Closing** (15s): Tagline + tech stack + GitHub link

---

## ✅ SUBMISSION CHECKLIST

- [ ] Open-source GitHub repo with all code
- [ ] 2-3 minute demo video (MP4, uploaded to YouTube/Vimeo)
- [ ] README.md with clear explanation
- [ ] Working ZK proof verification in Soroban contract
- [ ] Frontend with all three panels (Credential, Settlement, Regulator)
- [ ] All tests passing (`cargo test` + `nargo test`)
- [ ] Deployed to Stellar testnet (optional but recommended)

---

## 🆘 TROUBLESHOOTING

| Issue | Solution |
|-------|----------|
| `nargo: command not found` | Reinstall Noir: `bash <(curl -fsSL https://noir-lang.org/install)` |
| `bb: command not found` | Install Barretenberg: `npm install -g @aztec/bb.js` |
| `stellar: command not found` | `cargo install stellar-cli --locked` |
| `wasm32v1-none` not found | `rustup target add wasm32v1-none` |
| Contract deploy fails | Ensure local network running: `just start` |
| Proof verification fails | Check VK matches circuit, regenerate with `just build-circuits` |

---

## 📚 RESOURCES

- **Noir Docs**: https://noir-lang.org/docs/
- **Soroban Docs**: https://soroban.stellar.org/docs/
- **Stellar ZK Tutorial (Noir)**: https://jamesbachini.com/noir-on-stellar/
- **Stellar ZK Tutorial (RISC Zero)**: https://jamesbachini.com/stellar-risc-zero-games/
- **Stellar ZK Tutorial (Circom)**: https://jamesbachini.com/circom-on-stellar/
- **UltraHonk Verifier**: https://github.com/yugocabrio/rs-soroban-ultrahonk
- **RISC Zero Verifier**: https://github.com/NethermindEth/stellar-risc0-verifier/
- **Groth16 Verifier**: https://github.com/stellar/soroban-examples/tree/main/groth16_verifier

---

**Built for Stellar Hacks: Real-World ZK | June 2026**
