# Covenant — ZK-Verifiable Compliance Credentials for Cross-Border Private Settlement

> **Stellar Hacks: Real-World ZK | June 2026**

Covenant is a zero-knowledge credential system that enables **private cross-border stablecoin settlement with embedded compliance verification** on Stellar. Senders prove they satisfy regulatory requirements (KYC, sanctions screening, source-of-funds) through ZK proofs, without revealing their identity or transaction details to the public ledger, while preserving **auditable compliance trails** for regulators.

## 🎯 The Problem

Every cross-border payment on Stellar is public. Institutions like MoneyGram, Franklin Templeton, and PayPal cannot expose client data or competitive strategies on a public ledger. Yet regulators require compliance — KYC, AML, sanctions screening, source-of-funds verification.

**Today, privacy and compliance are treated as trade-offs. Covenant makes them mutually reinforcing.**

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    COVENANT SYSTEM                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  LAYER 1: NOIR ZK CIRCUITS (Off-Chain)                           │
│  ├── compliance_credential — Prove KYC, sanctions, risk score   │
│  └── private_settlement — Prove sufficient balance + compliance │
│                                                                  │
│  LAYER 2: SOROBAN SMART CONTRACTS (On-Chain)                     │
│  ├── CovenantRegistry — Stores credentials, nullifiers, tiers   │
│  ├── CovenantSettlement — Executes private settlements          │
│  └── CovenantComplianceBridge — Cross-currency settlement       │
│                                                                  │
│  LAYER 3: VIEW KEY & REGULATOR ACCESS (Compliance Layer)       │
│  └── Selective disclosure via view_key for authorized auditors  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Rust + wasm32 target
- Stellar CLI (^3.2.0)
- Noir 1.0.0-beta.9 + Barretenberg 0.87.0
- Node.js 18+

### Install

```bash
# Clone the repo
git clone https://github.com/dev-analyshd/covenant
cd covenant

# Install dependencies
just setup

# Start local Stellar network
just start

# Build circuits, deploy contracts, run end-to-end
just e2e
```

### Available Commands

| Command | Description |
|---------|-------------|
| `just setup` | Check dependencies, install packages |
| `just start` | Start local Stellar network |
| `just stop` | Stop local network |
| `just build-circuits` | Compile Noir circuits |
| `just build-contracts` | Build all Soroban contracts |
| `just deploy` | Deploy contracts to network |
| `just verify` | Run proof verification test |
| `just e2e` | Full end-to-end pipeline |
| `just testnet` | Deploy to Stellar testnet |
| `just frontend` | Start development frontend |

## 📁 Project Structure

```
covenant/
├── circuits/
│   ├── compliance_credential/    # Noir circuit for compliance proofs
│   └── private_settlement/       # Noir circuit for settlement proofs
├── contracts/
│   ├── covenant_registry/        # Credential registry contract
│   ├── covenant_settlement/      # Settlement execution contract
│   ├── covenant_compliance_bridge/ # Cross-currency settlement
│   └── ultrahonk_verifier/       # UltraHonk proof verifier
├── frontend/                     # React + TypeScript frontend
├── scripts/                      # Build & deployment scripts
├── test/                         # Integration tests
└── docs/                         # Documentation
```

## 🔐 ZK Circuits

### Compliance Credential Circuit

Proves:
- KYC verification from a trusted issuer (Merkle membership)
- Sanctions screening clearance (Merkle membership)
- Risk score within acceptable tier threshold (range proof)
- Credential not expired (timestamp comparison)

Public outputs: `nullifier`, `compliance_tier`, `address_commitment`

### Private Settlement Circuit

Proves:
- Amount is positive and within limits (range proof)
- Sender has sufficient balance (range proof)
- Recipient meets minimum compliance tier (comparison)
- Compliance credential is valid (proof verification)

Public outputs: `settlement_hash`, `compliance_attestation`, `sender_commitment`

## 📜 Smart Contracts

### CovenantRegistry

- `initialize(admin, issuer_root)` — Initialize with trusted issuer Merkle root
- `register_credential(proof, public_inputs)` — Register a compliance credential
- `verify_credential(nullifier)` — Verify credential is active
- `revoke_credential(nullifier, admin_sig)` — Revoke a credential (admin only)

### CovenantSettlement

- `initiate_settlement(proof, public_inputs, asset, amount, recipient)` — Execute private settlement
- `verify_settlement(settlement_id, proof)` — Verify settlement proof
- `regulator_audit(settlement_id, view_key)` — Selective disclosure for regulators

### CovenantComplianceBridge

- `cross_currency_settlement(src_asset, dst_asset, proof, amount)` — Cross-currency private settlement
- `verify_cross_currency_proof(proof)` — Verify cross-currency proof

## 🎨 Frontend

The frontend provides:
- **Credential Generation**: Generate compliance credentials with Noir proofs
- **Private Settlement**: Initiate private settlements with ZK verification
- **Regulator Dashboard**: Audit settlements with view keys (authorized access only)
- **Explorer**: View settlement history with compliance attestations

## 🧪 Testing

```bash
# Run all tests
cargo test --workspace --all-features --release

# Run circuit tests
nargo test

# Run integration tests
just e2e
```

## 🏆 Hackathon Submission

- **Open-source repo**: This repository
- **Demo video**: [Link to 2-3 minute walkthrough]
- **ZK + Stellar**: UltraHonk proofs verified in Soroban smart contracts

## 📄 License

MIT — This knowledge belongs to everyone.

## 🙏 Acknowledgments

- Stellar Development Foundation for Protocol 25/26 ZK primitives
- Aztec Protocol for Noir and Barretenberg
- Nethermind for rs-soroban-ultrahonk verifier
- James Bachini for Stellar ZK tutorials
- OpenZeppelin for configurable privacy standards

---

**Built for Stellar Hacks: Real-World ZK | June 2026**
