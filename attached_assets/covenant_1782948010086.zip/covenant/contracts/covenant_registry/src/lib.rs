#![no_std]
use soroban_sdk::{
    contract, contracterror, contractimpl, contracttype, 
    symbol_short, Address, Env, Map, Symbol, Vec, BytesN,
};

// ============================================================================
// CovenantRegistry Contract
// ============================================================================
// Stores and manages ZK-verifiable compliance credentials
// Each credential is registered after Noir proof verification
// ============================================================================

// Storage keys
const ADMIN: Symbol = symbol_short!("ADMIN");
const ISSUER_ROOT: Symbol = symbol_short!("IROOT");
const NULLIFIERS: Symbol = symbol_short!("NULLS");
const CRED_COUNT: Symbol = symbol_short!("CCOUNT");
const VK: Symbol = symbol_short!("VK");

// Credential struct stored on-chain
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ComplianceCredential {
    pub nullifier: BytesN<32>,
    pub tier: u32,
    pub expiry: u64,
    pub address_commitment: BytesN<32>,
    pub view_key_hash: BytesN<32>,
    pub registered_at: u64,
}

// Error types
#[contracterror]
#[derive(Copy, Clone, Debug, Eq, PartialEq, PartialOrd, Ord)]
#[repr(u32)]
pub enum RegistryError {
    AlreadyInitialized = 1,
    NotInitialized = 2,
    Unauthorized = 3,
    CredentialExpired = 4,
    NullifierReused = 5,
    CredentialNotFound = 6,
    InvalidProof = 7,
}

#[contract]
pub struct CovenantRegistry;

#[contractimpl]
impl CovenantRegistry {
    // ========================================================================
    // Initialize the registry
    // ========================================================================
    pub fn initialize(
        env: Env,
        admin: Address,
        issuer_root: BytesN<32>,
        verification_key: BytesN<32>,
    ) -> Result<(), RegistryError> {
        if env.storage().persistent().has(&ADMIN) {
            return Err(RegistryError::AlreadyInitialized);
        }

        admin.require_auth();

        env.storage().persistent().set(&ADMIN, &admin);
        env.storage().persistent().set(&ISSUER_ROOT, &issuer_root);
        env.storage().persistent().set(&VK, &verification_key);
        env.storage().persistent().set(&CRED_COUNT, &0u32);

        let nullifiers: Map<BytesN<32>, bool> = Map::new(&env);
        env.storage().persistent().set(&NULLIFIERS, &nullifiers);

        env.events().publish(
            (symbol_short!("init"), admin.clone()),
            issuer_root,
        );

        Ok(())
    }

    // ========================================================================
    // Register a compliance credential
    // ========================================================================
    pub fn register_credential(
        env: Env,
        caller: Address,
        nullifier: BytesN<32>,
        tier: u32,
        expiry: u64,
        address_commitment: BytesN<32>,
        view_key_hash: BytesN<32>,
    ) -> Result<u32, RegistryError> {
        caller.require_auth();

        if !env.storage().persistent().has(&ADMIN) {
            return Err(RegistryError::NotInitialized);
        }

        let nullifiers: Map<BytesN<32>, bool> = env.storage().persistent()
            .get(&NULLIFIERS)
            .unwrap();
        if nullifiers.get(nullifier.clone()).unwrap_or(false) {
            return Err(RegistryError::NullifierReused);
        }

        let current_time = env.ledger().timestamp();
        if expiry <= current_time {
            return Err(RegistryError::CredentialExpired);
        }

        if tier < 1 || tier > 5 {
            return Err(RegistryError::InvalidProof);
        }

        let credential = ComplianceCredential {
            nullifier: nullifier.clone(),
            tier,
            expiry,
            address_commitment,
            view_key_hash,
            registered_at: current_time,
        };

        let count: u32 = env.storage().persistent().get(&CRED_COUNT).unwrap();
        let cred_id = count;

        let cred_key = Symbol::new(&env, &format!("cred_{}", cred_id));
        env.storage().persistent().set(&cred_key, &credential);
        env.storage().persistent().set(&CRED_COUNT, &(count + 1));

        let mut updated_nullifiers = nullifiers;
        updated_nullifiers.set(nullifier.clone(), true);
        env.storage().persistent().set(&NULLIFIERS, &updated_nullifiers);

        env.events().publish(
            (symbol_short!("reg"), caller),
            (nullifier, tier, cred_id),
        );

        Ok(cred_id)
    }

    // ========================================================================
    // Verify a credential is active
    // ========================================================================
    pub fn verify_credential(
        env: Env,
        nullifier: BytesN<32>,
    ) -> Result<(u32, u64, BytesN<32>), RegistryError> {
        if !env.storage().persistent().has(&ADMIN) {
            return Err(RegistryError::NotInitialized);
        }

        let count: u32 = env.storage().persistent().get(&CRED_COUNT).unwrap();

        for i in 0..count {
            let cred_key = Symbol::new(&env, &format!("cred_{}", i));
            let credential: ComplianceCredential = env.storage().persistent()
                .get(&cred_key)
                .unwrap();

            if credential.nullifier == nullifier {
                let current_time = env.ledger().timestamp();
                if credential.expiry <= current_time {
                    return Err(RegistryError::CredentialExpired);
                }

                return Ok((credential.tier, credential.expiry, credential.address_commitment));
            }
        }

        Err(RegistryError::CredentialNotFound)
    }

    // ========================================================================
    // Revoke a credential (admin only)
    // ========================================================================
    pub fn revoke_credential(
        env: Env,
        admin: Address,
        nullifier: BytesN<32>,
    ) -> Result<(), RegistryError> {
        admin.require_auth();

        let stored_admin: Address = env.storage().persistent().get(&ADMIN).unwrap();
        if admin != stored_admin {
            return Err(RegistryError::Unauthorized);
        }

        let count: u32 = env.storage().persistent().get(&CRED_COUNT).unwrap();
        let mut found = false;

        for i in 0..count {
            let cred_key = Symbol::new(&env, &format!("cred_{}", i));
            let credential: ComplianceCredential = env.storage().persistent()
                .get(&cred_key)
                .unwrap();

            if credential.nullifier == nullifier {
                let mut revoked = credential;
                revoked.expiry = 0;
                env.storage().persistent().set(&cred_key, &revoked);
                found = true;
                break;
            }
        }

        if !found {
            return Err(RegistryError::CredentialNotFound);
        }

        env.events().publish(
            (symbol_short!("revoke"), admin),
            nullifier,
        );

        Ok(())
    }

    // ========================================================================
    // Get credential by ID
    // ========================================================================
    pub fn get_credential(
        env: Env,
        cred_id: u32,
    ) -> Result<ComplianceCredential, RegistryError> {
        let count: u32 = env.storage().persistent().get(&CRED_COUNT).unwrap();
        if cred_id >= count {
            return Err(RegistryError::CredentialNotFound);
        }

        let cred_key = Symbol::new(&env, &format!("cred_{}", cred_id));
        let credential: ComplianceCredential = env.storage().persistent()
            .get(&cred_key)
            .unwrap();

        Ok(credential)
    }

    // ========================================================================
    // Get total credential count
    // ========================================================================
    pub fn credential_count(env: Env) -> u32 {
        env.storage().persistent().get(&CRED_COUNT).unwrap_or(0)
    }

    // ========================================================================
    // Update issuer root (admin only)
    // ========================================================================
    pub fn update_issuer_root(
        env: Env,
        admin: Address,
        new_root: BytesN<32>,
    ) -> Result<(), RegistryError> {
        admin.require_auth();

        let stored_admin: Address = env.storage().persistent().get(&ADMIN).unwrap();
        if admin != stored_admin {
            return Err(RegistryError::Unauthorized);
        }

        env.storage().persistent().set(&ISSUER_ROOT, &new_root);

        env.events().publish(
            (symbol_short!("root_upd"), admin),
            new_root,
        );

        Ok(())
    }

    // ========================================================================
    // Get issuer root
    // ========================================================================
    pub fn get_issuer_root(env: Env) -> Result<BytesN<32>, RegistryError> {
        if !env.storage().persistent().has(&ISSUER_ROOT) {
            return Err(RegistryError::NotInitialized);
        }
        Ok(env.storage().persistent().get(&ISSUER_ROOT).unwrap())
    }
}

// ============================================================================
// Tests
// ============================================================================
#[cfg(test)]
mod test {
    use super::*;
    use soroban_sdk::testutils::Address as _;

    #[test]
    fn test_initialize() {
        let env = Env::default();
        let contract_id = env.register_contract(None, CovenantRegistry);
        let client = CovenantRegistryClient::new(&env, &contract_id);

        let admin = Address::generate(&env);
        let issuer_root = BytesN::from_array(&env, &[0u8; 32]);
        let vk = BytesN::from_array(&env, &[1u8; 32]);

        client.initialize(&admin, &issuer_root, &vk);

        assert_eq!(client.get_issuer_root(), Ok(issuer_root));
        assert_eq!(client.credential_count(), 0);
    }

    #[test]
    fn test_register_and_verify() {
        let env = Env::default();
        let contract_id = env.register_contract(None, CovenantRegistry);
        let client = CovenantRegistryClient::new(&env, &contract_id);

        let admin = Address::generate(&env);
        let issuer_root = BytesN::from_array(&env, &[0u8; 32]);
        let vk = BytesN::from_array(&env, &[1u8; 32]);

        client.initialize(&admin, &issuer_root, &vk);

        let caller = Address::generate(&env);
        let nullifier = BytesN::from_array(&env, &[2u8; 32]);
        let address_commitment = BytesN::from_array(&env, &[3u8; 32]);
        let view_key_hash = BytesN::from_array(&env, &[4u8; 32]);

        env.ledger().set_timestamp(1000);

        let cred_id = client.register_credential(
            &caller,
            &nullifier,
            &4u32,
            &999999u64,
            &address_commitment,
            &view_key_hash,
        );

        assert_eq!(cred_id, Ok(0));
        assert_eq!(client.credential_count(), 1);

        let result = client.verify_credential(&nullifier);
        assert!(result.is_ok());
        let (tier, expiry, _) = result.unwrap();
        assert_eq!(tier, 4);
        assert_eq!(expiry, 999999);
    }
}
