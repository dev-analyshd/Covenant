import React from 'react';
import { Shield, Lock, Eye, Zap, Globe, Activity, FileCheck, Database } from 'lucide-react';

const stats = [
    { label: 'Credentials Issued', value: '1,247', change: '+12%', icon: <Shield size={20} /> },
    { label: 'Private Settlements', value: '8,932', change: '+28%', icon: <Lock size={20} /> },
    { label: 'Cross-Currency', value: '3,456', change: '+15%', icon: <Globe size={20} /> },
    { label: 'Regulator Audits', value: '156', change: '+5%', icon: <Eye size={20} /> },
];

const recentActivity = [
    { type: 'credential', tier: 5, user: '0x7a3f...9e2d', time: '2 min ago', status: 'verified' },
    { type: 'settlement', amount: '$50,000', asset: 'USDC → EURC', time: '5 min ago', status: 'completed' },
    { type: 'audit', regulator: 'FCA', settlement: '0x9a2b...4c1e', time: '12 min ago', status: 'audited' },
    { type: 'credential', tier: 3, user: '0x3e8a...7f4c', time: '18 min ago', status: 'verified' },
];

export default function Dashboard() {
    return (
        <div className="space-y-8">
            {/* Hero Section */}
            <div className="glass-panel p-8 glow-border">
                <div className="flex items-start justify-between">
                    <div className="space-y-4">
                        <h2 className="text-3xl font-bold text-white">
                            Private Settlement with{' '}
                            <span className="text-blue-400">Provable Compliance</span>
                        </h2>
                        <p className="text-slate-400 max-w-2xl text-lg leading-relaxed">
                            Covenant enables institutions to execute cross-border stablecoin settlements
                            with zero-knowledge compliance verification. Prove KYC, sanctions clearance,
                            and risk scores without revealing identity or transaction details.
                        </p>
                        <div className="flex gap-4 pt-4">
                            <div className="flex items-center gap-2 text-emerald-400">
                                <Zap size={18} />
                                <span className="text-sm font-medium">Noir ZK Circuits</span>
                            </div>
                            <div className="flex items-center gap-2 text-blue-400">
                                <Activity size={18} />
                                <span className="text-sm font-medium">Soroban Smart Contracts</span>
                            </div>
                            <div className="flex items-center gap-2 text-purple-400">
                                <Shield size={18} />
                                <span className="text-sm font-medium">Stellar Protocol 26</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-4 gap-6">
                {stats.map((stat, i) => (
                    <div key={i} className="glass-panel p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-blue-400">
                                {stat.icon}
                            </div>
                            <span className="text-xs font-medium text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">
                                {stat.change}
                            </span>
                        </div>
                        <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                        <div className="text-sm text-slate-400">{stat.label}</div>
                    </div>
                ))}
            </div>

            {/* Architecture Diagram */}
            <div className="glass-panel p-8">
                <h3 className="text-lg font-semibold text-white mb-6">System Architecture</h3>
                <div className="grid grid-cols-3 gap-6">
                    <div className="space-y-4">
                        <div className="text-sm font-medium text-blue-400 uppercase tracking-wider">Layer 1: Noir ZK Circuits</div>
                        <div className="space-y-3">
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <FileCheck size={16} className="text-blue-400" />
                                    <span className="text-sm font-medium text-white">Compliance Credential</span>
                                </div>
                                <p className="text-xs text-slate-400">Proves KYC, sanctions, risk score</p>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <Lock size={16} className="text-blue-400" />
                                    <span className="text-sm font-medium text-white">Private Settlement</span>
                                </div>
                                <p className="text-xs text-slate-400">Proves balance + compliance</p>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="text-sm font-medium text-purple-400 uppercase tracking-wider">Layer 2: Soroban Contracts</div>
                        <div className="space-y-3">
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <Database size={16} className="text-purple-400" />
                                    <span className="text-sm font-medium text-white">CovenantRegistry</span>
                                </div>
                                <p className="text-xs text-slate-400">Stores credentials & nullifiers</p>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <Zap size={16} className="text-purple-400" />
                                    <span className="text-sm font-medium text-white">CovenantSettlement</span>
                                </div>
                                <p className="text-xs text-slate-400">Executes private settlements</p>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <Globe size={16} className="text-purple-400" />
                                    <span className="text-sm font-medium text-white">ComplianceBridge</span>
                                </div>
                                <p className="text-xs text-slate-400">Cross-currency settlement</p>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="text-sm font-medium text-emerald-400 uppercase tracking-wider">Layer 3: Compliance</div>
                        <div className="space-y-3">
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <Eye size={16} className="text-emerald-400" />
                                    <span className="text-sm font-medium text-white">View Key System</span>
                                </div>
                                <p className="text-xs text-slate-400">Selective disclosure for regulators</p>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="flex items-center gap-2 mb-2">
                                    <Shield size={16} className="text-emerald-400" />
                                    <span className="text-sm font-medium text-white">Stellar Compliance</span>
                                </div>
                                <p className="text-xs text-slate-400">Native freeze, clawback, auth</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Recent Activity */}
            <div className="glass-panel p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Recent Activity</h3>
                <div className="space-y-3">
                    {recentActivity.map((activity, i) => (
                        <div key={i} className="flex items-center justify-between p-4 rounded-lg bg-slate-800/30 border border-slate-700/50">
                            <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                                    activity.type === 'credential' ? 'bg-blue-500/10 text-blue-400' :
                                    activity.type === 'settlement' ? 'bg-purple-500/10 text-purple-400' :
                                    'bg-emerald-500/10 text-emerald-400'
                                }`}>
                                    {activity.type === 'credential' ? <FileCheck size={18} /> :
                                     activity.type === 'settlement' ? <Lock size={18} /> :
                                     <Eye size={18} />}
                                </div>
                                <div>
                                    <div className="text-sm font-medium text-white">
                                        {activity.type === 'credential' && `Tier ${activity.tier} Credential Issued`}
                                        {activity.type === 'settlement' && `Private Settlement ${activity.amount}`}
                                        {activity.type === 'audit' && `Regulator Audit by ${activity.regulator}`}
                                    </div>
                                    <div className="text-xs text-slate-400">
                                        {activity.user || activity.asset || activity.settlement} • {activity.time}
                                    </div>
                                </div>
                            </div>
                            <span className={`text-xs font-medium px-3 py-1 rounded-full ${
                                activity.status === 'verified' ? 'bg-blue-500/10 text-blue-400' :
                                activity.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400' :
                                'bg-purple-500/10 text-purple-400'
                            }`}>
                                {activity.status}
                            </span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
