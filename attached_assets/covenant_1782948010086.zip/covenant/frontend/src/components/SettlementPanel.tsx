import React, { useState } from 'react';
import { Lock, Globe, AlertCircle, CheckCircle, Loader } from 'lucide-react';

export default function SettlementPanel() {
    const [step, setStep] = useState<'form' | 'proving' | 'completed'>('form');
    const [isCrossCurrency, setIsCrossCurrency] = useState(false);

    const handleSettle = async () => {
        setStep('proving');
        await new Promise(r => setTimeout(r, 3000));
        setStep('completed');
    };

    return (
        <div className="max-w-2xl mx-auto space-y-6">
            <div className="glass-panel p-8">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
                        <Lock className="text-purple-400" size={24} />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-white">Private Settlement</h2>
                        <p className="text-sm text-slate-400">Execute a ZK-verified private transfer</p>
                    </div>
                </div>

                {step === 'form' && (
                    <div className="space-y-6">
                        <div className="flex items-center gap-4 p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                            <label className="flex items-center gap-3 cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={isCrossCurrency}
                                    onChange={e => setIsCrossCurrency(e.target.checked)}
                                    className="w-5 h-5 rounded border-slate-600 bg-slate-800 text-blue-500 focus:ring-blue-500"
                                />
                                <div>
                                    <div className="text-sm font-medium text-white">Cross-Currency Settlement</div>
                                    <div className="text-xs text-slate-400">Convert between stablecoins via Stellar DEX</div>
                                </div>
                            </label>
                            <Globe className="text-slate-500 ml-auto" size={20} />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">From Asset</label>
                                <select className="input-field">
                                    <option>USDC</option>
                                    <option>EURC</option>
                                    <option>PYUSD</option>
                                    <option>GYEN</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">To Asset</label>
                                <select className="input-field">
                                    <option>USDC</option>
                                    <option selected>EURC</option>
                                    <option>PYUSD</option>
                                    <option>GYEN</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-300 mb-2">Amount</label>
                            <div className="relative">
                                <input
                                    type="number"
                                    className="input-field pr-16"
                                    placeholder="0.00"
                                />
                                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 text-sm">USDC</span>
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-300 mb-2">Recipient</label>
                            <input
                                type="text"
                                className="input-field"
                                placeholder="G... (Stellar address)"
                            />
                        </div>

                        <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700 space-y-2">
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Your Compliance Tier</span>
                                <span className="tier-badge tier-4">Tier 4</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Settlement Limit</span>
                                <span className="text-white">$800,000</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">ZK Proof Required</span>
                                <span className="text-emerald-400">✓ Verified</span>
                            </div>
                        </div>

                        <button onClick={handleSettle} className="btn-primary w-full">
                            <span className="flex items-center justify-center gap-2">
                                <Lock size={18} />
                                Execute Private Settlement
                            </span>
                        </button>
                    </div>
                )}

                {step === 'proving' && (
                    <div className="py-12 text-center space-y-4">
                        <div className="w-16 h-16 rounded-full bg-purple-500/10 flex items-center justify-center mx-auto animate-pulse">
                            <Loader className="text-purple-400 animate-spin" size={32} />
                        </div>
                        <h3 className="text-lg font-semibold text-white">Generating Settlement Proof...</h3>
                        <p className="text-sm text-slate-400">Verifying compliance and balance in Noir circuit</p>
                    </div>
                )}

                {step === 'completed' && (
                    <div className="space-y-6">
                        <div className="text-center py-8">
                            <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                                <CheckCircle className="text-emerald-400" size={32} />
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2">Settlement Complete!</h3>
                            <p className="text-sm text-slate-400">Your private settlement has been executed</p>
                        </div>

                        <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700 space-y-3">
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Settlement Hash</span>
                                <span className="text-white font-mono">0x3e8a...7f4c</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Amount</span>
                                <span className="text-white">$50,000 USDC → EURC</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Compliance Tier</span>
                                <span className="tier-badge tier-4">Tier 4</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Status</span>
                                <span className="text-emerald-400">Completed</span>
                            </div>
                        </div>

                        <button onClick={() => setStep('form')} className="btn-secondary w-full">
                            New Settlement
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
