import React, { useState } from 'react';
import { FileCheck, Shield, AlertCircle, CheckCircle, Loader } from 'lucide-react';

export default function CredentialPanel() {
    const [step, setStep] = useState<'form' | 'proving' | 'verified'>('form');
    const [formData, setFormData] = useState({
        kycProvider: '',
        riskScore: '',
        sourceOfFunds: '',
    });

    const handleGenerate = async () => {
        setStep('proving');
        await new Promise(r => setTimeout(r, 3000));
        setStep('verified');
    };

    return (
        <div className="max-w-2xl mx-auto space-y-6">
            <div className="glass-panel p-8">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                        <FileCheck className="text-blue-400" size={24} />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-white">Generate Compliance Credential</h2>
                        <p className="text-sm text-slate-400">Create a ZK-verifiable compliance credential</p>
                    </div>
                </div>

                {step === 'form' && (
                    <div className="space-y-6">
                        <div className="p-4 rounded-lg bg-blue-500/5 border border-blue-500/20">
                            <div className="flex items-start gap-3">
                                <AlertCircle className="text-blue-400 mt-0.5" size={18} />
                                <div className="text-sm text-slate-300">
                                    <p className="font-medium text-white mb-1">Privacy Notice</p>
                                    Your KYC data is never stored on-chain. Only a zero-knowledge proof of compliance is published.
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">KYC Provider</label>
                                <select
                                    className="input-field"
                                    value={formData.kycProvider}
                                    onChange={e => setFormData({...formData, kycProvider: e.target.value})}
                                >
                                    <option value="">Select provider...</option>
                                    <option value="onfido">Onfido</option>
                                    <option value="jumio">Jumio</option>
                                    <option value="sumsub">SumSub</option>
                                    <option value="fractal">Fractal ID</option>
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">Risk Score (0-100)</label>
                                <input
                                    type="number"
                                    min="0"
                                    max="100"
                                    className="input-field"
                                    placeholder="Enter risk score..."
                                    value={formData.riskScore}
                                    onChange={e => setFormData({...formData, riskScore: e.target.value})}
                                />
                                <p className="text-xs text-slate-500 mt-1">Lower score = higher compliance tier</p>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">Source of Funds</label>
                                <select
                                    className="input-field"
                                    value={formData.sourceOfFunds}
                                    onChange={e => setFormData({...formData, sourceOfFunds: e.target.value})}
                                >
                                    <option value="">Select source...</option>
                                    <option value="salary">Salary / Employment</option>
                                    <option value="business">Business Revenue</option>
                                    <option value="investment">Investment Returns</option>
                                    <option value="inheritance">Inheritance</option>
                                    <option value="other">Other (Specify)</option>
                                </select>
                            </div>
                        </div>

                        <button onClick={handleGenerate} className="btn-primary w-full">
                            <span className="flex items-center justify-center gap-2">
                                <Shield size={18} />
                                Generate ZK Credential
                            </span>
                        </button>
                    </div>
                )}

                {step === 'proving' && (
                    <div className="py-12 text-center space-y-4">
                        <div className="w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto animate-pulse">
                            <Loader className="text-blue-400 animate-spin" size={32} />
                        </div>
                        <h3 className="text-lg font-semibold text-white">Generating ZK Proof...</h3>
                        <p className="text-sm text-slate-400">Computing compliance credential in Noir circuit</p>
                        <div className="max-w-xs mx-auto">
                            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                                <div className="h-full bg-blue-500 rounded-full animate-pulse" style={{width: '60%'}} />
                            </div>
                        </div>
                    </div>
                )}

                {step === 'verified' && (
                    <div className="space-y-6">
                        <div className="text-center py-8">
                            <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                                <CheckCircle className="text-emerald-400" size={32} />
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2">Credential Verified!</h3>
                            <p className="text-sm text-slate-400">Your compliance credential is now on-chain</p>
                        </div>

                        <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700 space-y-3">
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Credential ID</span>
                                <span className="text-white font-mono">0x7a3f...9e2d</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Compliance Tier</span>
                                <span className="tier-badge tier-4">Tier 4</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Nullifier</span>
                                <span className="text-white font-mono">0x9a2b...4c1e</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Expires</span>
                                <span className="text-white">Sep 23, 2026</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-slate-400">Transaction</span>
                                <a href="#" className="text-blue-400 hover:underline">View on Stellar Explorer</a>
                            </div>
                        </div>

                        <button onClick={() => setStep('form')} className="btn-secondary w-full">
                            Generate Another Credential
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
