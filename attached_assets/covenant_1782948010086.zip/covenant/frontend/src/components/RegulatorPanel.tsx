import React, { useState } from 'react';
import { Eye, Shield, Search, FileText, AlertCircle } from 'lucide-react';

export default function RegulatorPanel() {
    const [viewKey, setViewKey] = useState('');
    const [settlementId, setSettlementId] = useState('');
    const [auditResult, setAuditResult] = useState<null | any>(null);

    const handleAudit = () => {
        setAuditResult({
            settlementId: '0x3e8a...7f4c',
            complianceTier: 4,
            amount: '$50,000',
            asset: 'USDC → EURC',
            senderCommitment: '0x7a3f...9e2d',
            timestamp: '2026-06-23 14:32:18 UTC',
            kycProvider: 'Onfido',
            sanctionsStatus: 'Cleared',
            riskScore: 15,
            sourceOfFunds: 'Business Revenue',
        });
    };

    return (
        <div className="max-w-3xl mx-auto space-y-6">
            <div className="glass-panel p-8">
                <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                        <Eye className="text-emerald-400" size={24} />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-white">Regulator Audit Portal</h2>
                        <p className="text-sm text-slate-400">Authorized selective disclosure for compliance monitoring</p>
                    </div>
                </div>

                <div className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20 mb-6">
                    <div className="flex items-start gap-3">
                        <AlertCircle className="text-amber-400 mt-0.5" size={18} />
                        <div className="text-sm text-slate-300">
                            <p className="font-medium text-white mb-1">Authorized Access Only</p>
                            This portal requires a valid regulator view key. All audit actions are logged on-chain.
                        </div>
                    </div>
                </div>

                <div className="space-y-4 mb-8">
                    <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">Settlement ID</label>
                        <div className="relative">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                            <input
                                type="text"
                                className="input-field pl-12"
                                placeholder="Enter settlement ID..."
                                value={settlementId}
                                onChange={e => setSettlementId(e.target.value)}
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">View Key</label>
                        <input
                            type="password"
                            className="input-field"
                            placeholder="Enter regulator view key..."
                            value={viewKey}
                            onChange={e => setViewKey(e.target.value)}
                        />
                    </div>

                    <button onClick={handleAudit} className="btn-primary w-full">
                        <span className="flex items-center justify-center gap-2">
                            <Eye size={18} />
                            Audit Settlement
                        </span>
                    </button>
                </div>

                {auditResult && (
                    <div className="space-y-4">
                        <div className="flex items-center gap-2 mb-4">
                            <FileText className="text-emerald-400" size={20} />
                            <h3 className="text-lg font-semibold text-white">Audit Report</h3>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Settlement ID</div>
                                <div className="text-sm font-mono text-white">{auditResult.settlementId}</div>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Compliance Tier</div>
                                <span className="tier-badge tier-4">Tier {auditResult.complianceTier}</span>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Amount</div>
                                <div className="text-sm font-medium text-white">{auditResult.amount}</div>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Asset</div>
                                <div className="text-sm font-medium text-white">{auditResult.asset}</div>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">KYC Provider</div>
                                <div className="text-sm font-medium text-white">{auditResult.kycProvider}</div>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Sanctions Status</div>
                                <div className="text-sm font-medium text-emerald-400">{auditResult.sanctionsStatus}</div>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Risk Score</div>
                                <div className="text-sm font-medium text-white">{auditResult.riskScore}/100</div>
                            </div>
                            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                                <div className="text-xs text-slate-400 mb-1">Source of Funds</div>
                                <div className="text-sm font-medium text-white">{auditResult.sourceOfFunds}</div>
                            </div>
                        </div>

                        <div className="p-4 rounded-lg bg-slate-800/30 border border-slate-700">
                            <div className="text-xs text-slate-400 mb-2">Sender Commitment (Privacy-Preserving)</div>
                            <div className="text-sm font-mono text-slate-300">{auditResult.senderCommitment}</div>
                            <p className="text-xs text-slate-500 mt-2">
                                The sender's actual address is not revealed. Only the commitment is available for correlation analysis.
                            </p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
