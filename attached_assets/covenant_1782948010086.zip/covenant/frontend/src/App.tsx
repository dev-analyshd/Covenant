import React, { useState } from 'react';
import { Shield, Lock, Eye, Zap, Globe, Activity, FileCheck } from 'lucide-react';
import CredentialPanel from './components/CredentialPanel';
import SettlementPanel from './components/SettlementPanel';
import RegulatorPanel from './components/RegulatorPanel';
import Dashboard from './components/Dashboard';

type Tab = 'dashboard' | 'credential' | 'settlement' | 'regulator';

export default function App() {
    const [activeTab, setActiveTab] = useState<Tab>('dashboard');
    const [walletConnected, setWalletConnected] = useState(false);

    const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
        { id: 'dashboard', label: 'Dashboard', icon: <Activity size={18} /> },
        { id: 'credential', label: 'Credential', icon: <FileCheck size={18} /> },
        { id: 'settlement', label: 'Settlement', icon: <Zap size={18} /> },
        { id: 'regulator', label: 'Regulator', icon: <Eye size={18} /> },
    ];

    return (
        <div className="min-h-screen bg-[var(--color-bg)]">
            {/* Header */}
            <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-lg sticky top-0 z-50">
                <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
                            <Shield className="text-white" size={20} />
                        </div>
                        <div>
                            <h1 className="text-xl font-bold text-white tracking-tight">Covenant</h1>
                            <p className="text-xs text-slate-400">ZK Compliance Credentials</p>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                            <span className="text-xs text-emerald-400 font-medium">Stellar Testnet</span>
                        </div>
                        <button
                            onClick={() => setWalletConnected(!walletConnected)}
                            className={walletConnected ? 'btn-secondary' : 'btn-primary'}
                        >
                            {walletConnected ? (
                                <span className="flex items-center gap-2">
                                    <Lock size={16} />
                                    G...7x9A
                                </span>
                            ) : (
                                <span className="flex items-center gap-2">
                                    <Globe size={16} />
                                    Connect Wallet
                                </span>
                            )}
                        </button>
                    </div>
                </div>
            </header>

            {/* Navigation */}
            <nav className="border-b border-slate-800 bg-slate-900/30">
                <div className="max-w-7xl mx-auto px-6">
                    <div className="flex gap-1">
                        {tabs.map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all ${
                                    activeTab === tab.id
                                        ? 'border-blue-500 text-blue-400'
                                        : 'border-transparent text-slate-400 hover:text-slate-200'
                                }`}
                            >
                                {tab.icon}
                                {tab.label}
                            </button>
                        ))}
                    </div>
                </div>
            </nav>

            {/* Main Content */}
            <main className="max-w-7xl mx-auto px-6 py-8">
                {activeTab === 'dashboard' && <Dashboard />}
                {activeTab === 'credential' && <CredentialPanel />}
                {activeTab === 'settlement' && <SettlementPanel />}
                {activeTab === 'regulator' && <RegulatorPanel />}
            </main>

            {/* Footer */}
            <footer className="border-t border-slate-800 mt-16 py-8">
                <div className="max-w-7xl mx-auto px-6 flex items-center justify-between text-slate-500 text-sm">
                    <div className="flex items-center gap-2">
                        <Shield size={16} />
                        <span>Covenant — Stellar Hacks: Real-World ZK 2026</span>
                    </div>
                    <div className="flex items-center gap-6">
                        <span>Built with Noir + Soroban</span>
                        <span className="text-slate-600">|</span>
                        <span>MIT License</span>
                    </div>
                </div>
            </footer>
        </div>
    );
}
