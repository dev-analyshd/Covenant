#!/bin/bash
set -e

CIRCUIT=${1:-compliance_credential}

echo "=== Generating ZK Proof for $CIRCUIT ==="

cd "circuits/$CIRCUIT"

# Compile circuit
echo "Compiling circuit..."
nargo compile

# Execute witness generation
echo "Generating witness..."
nargo execute

# Generate proof with Barretenberg
echo "Generating UltraHonk proof..."
bb prove -b ./target/"$CIRCUIT".json -w ./target/"$CIRCUIT".gz -o ./target

# Write verification key
echo "Writing verification key..."
bb write_vk -b ./target/"$CIRCUIT".json -o ./target

echo "=== Proof Generated ==="
echo "Proof: ./target/proof"
echo "VK: ./target/vk"
echo "Public Inputs: ./target/public_inputs"
