#!/bin/bash
set -e

echo "=== Covenant Deployment Script ==="

# Configuration
NETWORK=${STELLAR_NETWORK_NAME:-local}
ADMIN_KEY="alice"

# Generate/fund admin account
echo "Funding admin account..."
stellar keys generate "$ADMIN_KEY" --network "$NETWORK" --fund 2>/dev/null || true

# Build contracts
echo "Building contracts..."
cargo build --workspace --release --target wasm32v1-none

# Deploy CovenantRegistry
echo "Deploying CovenantRegistry..."
REGISTRY_ID=$(stellar contract deploy \
    --wasm target/wasm32v1-none/release/covenant_registry.wasm \
    --source-account "$ADMIN_KEY" \
    --network "$NETWORK" \
    --alias covenant_registry)

echo "Registry deployed: $REGISTRY_ID"

# Initialize Registry
echo "Initializing Registry..."
ISSUER_ROOT="0x0000000000000000000000000000000000000000000000000000000000000000"
VK="0x0101010101010101010101010101010101010101010101010101010101010101"

stellar contract invoke \
    --id covenant_registry \
    --source-account "$ADMIN_KEY" \
    --network "$NETWORK" \
    -- \
    initialize \
    --admin "$(stellar keys address "$ADMIN_KEY")" \
    --issuer_root "$ISSUER_ROOT" \
    --verification_key "$VK"

# Deploy CovenantSettlement
echo "Deploying CovenantSettlement..."
SETTLEMENT_ID=$(stellar contract deploy \
    --wasm target/wasm32v1-none/release/covenant_settlement.wasm \
    --source-account "$ADMIN_KEY" \
    --network "$NETWORK" \
    --alias covenant_settlement)

echo "Settlement deployed: $SETTLEMENT_ID"

# Initialize Settlement
stellar contract invoke \
    --id covenant_settlement \
    --source-account "$ADMIN_KEY" \
    --network "$NETWORK" \
    -- \
    initialize \
    --admin "$(stellar keys address "$ADMIN_KEY")" \
    --registry_address "$REGISTRY_ID"

# Deploy CovenantComplianceBridge
echo "Deploying CovenantComplianceBridge..."
BRIDGE_ID=$(stellar contract deploy \
    --wasm target/wasm32v1-none/release/covenant_compliance_bridge.wasm \
    --source-account "$ADMIN_KEY" \
    --network "$NETWORK" \
    --alias covenant_compliance_bridge)

echo "Bridge deployed: $BRIDGE_ID"

# Initialize Bridge
stellar contract invoke \
    --id covenant_compliance_bridge \
    --source-account "$ADMIN_KEY" \
    --network "$NETWORK" \
    -- \
    initialize \
    --admin "$(stellar keys address "$ADMIN_KEY")" \
    --settlement_address "$SETTLEMENT_ID"

echo "=== Deployment Complete ==="
echo "Registry: $REGISTRY_ID"
echo "Settlement: $SETTLEMENT_ID"
echo "Bridge: $BRIDGE_ID"
