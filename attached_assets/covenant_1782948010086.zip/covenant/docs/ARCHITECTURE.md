# Covenant Architecture

## Overview

Covenant is a three-layer system:

```
┌─────────────────────────────────────────────────────────────┐
│ LAYER 3: COMPLIANCE & VIEW KEYS                              │
│ • Selective disclosure for authorized regulators               │
│ • Stellar-native compliance primitives (freeze, clawback)     │
├─────────────────────────────────────────────────────────────┤
│ LAYER 2: SOROBAN SMART CONTRACTS                             │
│ • CovenantRegistry — Credential storage & nullifier tracking │
│ • CovenantSettlement — Private settlement execution            │
│ • CovenantComplianceBridge — Cross-currency settlement       │
│ • UltraHonkVerifier — ZK proof verification                  │
├─────────────────────────────────────────────────────────────┤
│ LAYER 1: NOIR ZK CIRCUITS                                    │
│ • Compliance Credential — Prove KYC, sanctions, risk score   │
│ • Private Settlement — Prove balance + compliance              │
└─────────────────────────────────────────────────────────────┘
```

## ZK Proof Flow

1. **User generates compliance credential off-chain**
   - Inputs: KYC hash, sanctions hash, risk score, credential secret
   - Circuit verifies Merkle membership in trusted issuer set
   - Outputs: nullifier, compliance_tier, address_commitment, view_key_hash

2. **Credential is registered on-chain**
   - User submits proof to CovenantRegistry
   - Contract verifies proof via UltraHonkVerifier
   - Nullifier is marked as used (prevents replay)

3. **User initiates private settlement**
   - Inputs: amount, balance, compliance_tier, sender_secret
   - Circuit verifies sufficient balance + valid compliance
   - Outputs: settlement_hash, compliance_attestation

4. **Settlement is executed on-chain**
   - CovenantSettlement verifies settlement proof
   - Executes token transfer via Stellar Asset Contract
   - Stores encrypted compliance trail for regulator audit

## Security Model

- **Privacy**: User identity never revealed on-chain
- **Compliance**: Regulators can audit with view keys
- **Non-repudiation**: All actions logged with commitments
- **Replay protection**: Nullifiers prevent credential reuse
