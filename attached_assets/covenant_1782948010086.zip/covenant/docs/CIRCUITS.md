# Noir Circuit Specifications

## Compliance Credential Circuit

### Private Inputs
| Input | Type | Description |
|-------|------|-------------|
| kyc_hash | Field | Hash of KYC verification document |
| sanctions_hash | Field | Hash of sanctions screening result |
| source_commitment | Field | Commitment to source of funds |
| risk_score | u32 | Internal risk assessment (0-100) |
| credential_secret | Field | User's unique credential secret |
| kyc_path | [Field; 32] | Merkle path for KYC hash |
| kyc_indices | [u32; 32] | Path indices for KYC |
| sanctions_path | [Field; 32] | Merkle path for sanctions hash |
| sanctions_indices | [u32; 32] | Path indices for sanctions |

### Public Inputs
| Input | Type | Description |
|-------|------|-------------|
| trusted_issuer_root | Field | Merkle root of trusted KYC issuers |
| negative_screening_root | Field | Merkle root of cleared sanctions |
| current_timestamp | u64 | Current block timestamp |
| expiry_timestamp | u64 | Credential expiry time |
| tier_threshold | u32 | Maximum risk score for tier |

### Public Outputs
| Output | Type | Description |
|--------|------|-------------|
| nullifier | Field | Prevents double-spending |
| compliance_tier | u32 | Computed tier (1-5) |
| address_commitment | Field | Public identifier |
| view_key_hash | Field | Hash for regulator view key |

### Constraints
1. KYC hash ∈ TrustedIssuerMerkleTree
2. Sanctions hash ∈ NegativeScreeningMerkleTree
3. risk_score ≤ tier_threshold
4. expiry_timestamp > current_timestamp
5. source_commitment ≠ 0

## Private Settlement Circuit

### Private Inputs
| Input | Type | Description |
|-------|------|-------------|
| amount | u64 | Transfer amount |
| sender_balance | u64 | Sender's current balance |
| compliance_tier | u32 | Sender's compliance tier |
| sender_secret | Field | Sender's credential secret |
| recipient_tier | u32 | Recipient's compliance tier |

### Public Inputs
| Input | Type | Description |
|-------|------|-------------|
| settlement_id | Field | Unique settlement identifier |
| min_recipient_tier | u32 | Minimum tier required |
| max_amount | u64 | Maximum amount per settlement |
| asset_id | Field | Asset being transferred |
| compliance_nullifier | Field | Nullifier from compliance credential |
| current_timestamp | u64 | Current block timestamp |

### Public Outputs
| Output | Type | Description |
|--------|------|-------------|
| settlement_hash | Field | Deterministic settlement identifier |
| compliance_attestation | bool | True if all constraints satisfied |
| sender_commitment | Field | Sender's public commitment |
| tier_limit | u64 | Tier-adjusted amount limit |

### Constraints
1. amount > 0
2. amount ≤ max_amount
3. sender_balance ≥ amount
4. compliance_tier ≥ 1 AND ≤ 5
5. recipient_tier ≥ min_recipient_tier
6. compliance_nullifier ≠ 0
7. amount ≤ tier_limit(compliance_tier)
