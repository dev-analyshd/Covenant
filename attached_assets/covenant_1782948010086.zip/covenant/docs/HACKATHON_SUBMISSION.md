# Covenant — Stellar Hacks: Real-World ZK Submission

## Project Overview

**Covenant** is a zero-knowledge credential system that enables **private cross-border stablecoin settlement with embedded compliance verification** on Stellar.

### The Problem
Every cross-border payment on Stellar is public. Institutions like MoneyGram, Franklin Templeton, and PayPal cannot expose client data or competitive strategies on a public ledger. Yet regulators require compliance — KYC, AML, sanctions screening, source-of-funds verification.

**Today, privacy and compliance are treated as trade-offs. Covenant makes them mutually reinforcing.**

### The Solution
- Users generate ZK proofs of compliance (KYC, sanctions, risk score) off-chain using Noir circuits
- Proofs are verified on-chain in Soroban smart contracts using Stellar's native BN254 host functions
- Regulators can audit settlements with view keys for selective disclosure
- All without revealing user identity or transaction details to the public ledger

## Technical Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| ZK Circuits | Noir 1.0-beta.9 | Compliance & settlement proofs |
| Proving Backend | Barretenberg 0.87.0 | UltraHonk proof generation |
| Smart Contracts | Soroban (Rust/WASM) | On-chain verification & settlement |
| Proof Verification | BN254 Host Functions | Protocol 25/26 native ZK verification |
| Frontend | React + TypeScript | User interface |
| Hash Function | Poseidon2 | Native host function for Merkle trees |

## Key Features

1. **Compliance Credential Circuit**: Proves KYC verification, sanctions clearance, and risk score within tier threshold
2. **Private Settlement Circuit**: Proves sufficient balance and valid compliance without revealing amounts
3. **CovenantRegistry**: Stores credentials with nullifier tracking (prevents replay)
4. **CovenantSettlement**: Executes private settlements with Stellar Asset Contract integration
5. **CovenantComplianceBridge**: Cross-currency settlement via Stellar DEX path payment
6. **View Key System**: Selective disclosure for authorized regulators

## Demo Video Script (2-3 minutes)

**[0:00-0:30] The Problem**
- Show Stellar explorer with public transaction
- "Every cross-border payment is visible to everyone"
- "Institutions can't expose client data"
- "Regulators need compliance. Users need privacy."

**[0:30-1:30] The Solution: Covenant**
- Show frontend: "Generate Compliance Credential"
- Walk through form (KYC provider, risk score, source of funds)
- Click "Generate ZK Credential"
- Show terminal: `nargo prove` running
- Show proof verification on-chain
- "The proof is verified. The data stays private."

**[1:30-2:15] Private Settlement**
- Switch to Settlement tab
- Enter amount, select USDC → EURC
- Click "Execute Private Settlement"
- Show transaction confirmation
- Show settlement hash on Stellar explorer
- "The settlement is complete. The details are private."

**[2:15-2:45] Regulator Audit**
- Switch to Regulator tab
- Enter settlement ID and view key
- Click "Audit Settlement"
- Show decrypted compliance trail
- "Regulators get what they need. Everyone else sees nothing."

**[2:45-3:00] Closing**
- "Covenant: Privacy with Provable Compliance"
- "Built with Noir + Soroban on Stellar"
- GitHub link, team info

## Why This Wins

| Criterion | Covenant's Advantage |
|-----------|-------------------|
| **ZK is load-bearing** | Every transaction requires a ZK proof; without it, the contract rejects |
| **Real-world use case** | Directly addresses Stellar's core mission: institutional cross-border payments |
| **Uses Stellar's unique strengths** | Leverages native compliance primitives + multi-currency stablecoin ecosystem |
| **Technical sophistication** | Noir circuits with Merkle proofs, range proofs, nullifiers + Soroban verification |
| **Novelty** | No existing project combines ZK privacy with provable compliance on any chain |
| **Ecosystem fit** | Aligns with SDF's "configurable privacy" strategy and institutional partners |

## Repository Structure

```
covenant/
├── README.md                          # Project overview
├── Cargo.toml                         # Workspace configuration
├── package.json                       # Frontend dependencies
├── justfile                           # Task runner
├── circuits/
│   ├── compliance_credential/         # Noir circuit
│   └── private_settlement/            # Noir circuit
├── contracts/
│   ├── covenant_registry/             # Credential registry
│   ├── covenant_settlement/           # Settlement execution
│   ├── covenant_compliance_bridge/    # Cross-currency bridge
│   └── ultrahonk_verifier/            # Proof verifier
├── frontend/                          # React application
├── scripts/                           # Build & deployment
└── docs/                              # Documentation
```

## Quick Start

```bash
# Install dependencies
just setup

# Start local Stellar network
just start

# Build circuits
just build-circuits

# Build contracts
just build-contracts

# Deploy
just deploy

# Run end-to-end
just e2e
```

## Team

Built for Stellar Hacks: Real-World ZK | June 2026

**License**: MIT — This knowledge belongs to everyone.
